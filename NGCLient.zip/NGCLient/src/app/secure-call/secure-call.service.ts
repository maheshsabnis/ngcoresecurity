import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {
  RegisterUser,
  LoginUser,
  Product,
  ResponseData
} from './secure-call.models';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class SecureCallService {
  url: string;
  constructor(private httpClient: HttpClient) {
    this.url = 'http://localhost:16237';
  }

  // method to register the user
  registerUser(user: RegisterUser): Observable<ResponseData> {
    let userRegistered: Observable<ResponseData>;
    const options = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    userRegistered = this.httpClient.post<ResponseData>(
      `${this.url}/api/Authentication/Register`,
      user,
      options
    );
    return userRegistered;
  }

  // method to login the user the user
  authenticateUser(user: LoginUser): Observable<ResponseData> {
    let userAuthenticated: Observable<ResponseData>;
    // const userData = "username=" + user.UserName + "&password=" + user.Password + "&grant_type=password";

    const options = {
      headers: new HttpHeaders({
        // 'Content-Type': 'application/x-www-form-urlencoded'
        'Content-Type': 'application/json'
      })
    };
    userAuthenticated = this.httpClient.post<ResponseData>(
      `${this.url}/api/Authentication/Login`,
      user,
      options
    );
    return userAuthenticated;
  }

  // method to get products
  getProducts(token: string): Observable<Product[]> {
     alert(`in Service ${token}`);
     let products: Observable<Product[]>;
     const headerValues = new HttpHeaders();

    //  const options = {
    //    headers: new HttpHeaders({
    //     // tslint:disable-next-line: object-literal-key-quotes
    //     'Authorization' : `Bearer ${token}`
    //    })
    // };
    //  products = this.httpClient.get<Product[]>(
    //   `${this.url}/api/Products`,
    //  // options
    // );
    // tslint:disable-next-line: align
    products = this.httpClient.get<Product[]>(`${this.url}/api/Products`);
     return products;
  }
}
